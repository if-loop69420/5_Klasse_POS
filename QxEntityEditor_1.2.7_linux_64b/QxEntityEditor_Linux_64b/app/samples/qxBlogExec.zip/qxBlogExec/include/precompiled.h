#ifndef _QX_BLOG_EXEC_PRECOMPILED_HEADER_H_
#define _QX_BLOG_EXEC_PRECOMPILED_HEADER_H_

#include <QxOrm.h>

#include "export.h"

#endif // _QX_BLOG_EXEC_PRECOMPILED_HEADER_H_
