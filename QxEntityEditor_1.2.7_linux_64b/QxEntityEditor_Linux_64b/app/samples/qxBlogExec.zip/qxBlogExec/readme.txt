
--------------------------------------------
-- To build qxBlogExec project with qmake --
--------------------------------------------

1- Export the 'qxBlog.qxee' project as a C++ project with QxEntityEditor and build it
2- Open the 'qxBlogExec.pro' file
3- Replace '$$(QXORM_DIR)' by your QxOrm library installation path
4- Replace 'C:/Temp/qxee/cpp/' by the path where you have exported the 'qxBlog.qxee' project as a C++ project
5- run command line : qmake
6- run command line : make debug (or make release)


--------------------------------------------
-- To build qxBlogExec project with CMake --
--------------------------------------------

1- Export the 'qxBlog.qxee' project as a C++ project with QxEntityEditor and build it
2- Open the 'CMakeLists.txt' file
3- Replace '$ENV{QXORM_DIR}' by your QxOrm library installation path
4- Replace 'C:/Temp/qxee/cpp/' by the path where you have exported the 'qxBlog.qxee' project as a C++ project
5- run cmake or cmake-gui to configure and generate your make files
